# @luna/theme-chalk

Luna UI 的主题变量、组件级变量与 Sass 工具。全局样式入口只负责输出 Light / Dark 主题，其他模块均无 CSS 副作用。

```text
src/
├── alert.scss    # 根级、每组件独立的主题变量
├── avatar.scss
├── button.scss
├── calendar.scss
├── card.scss
├── cell.scss
├── checkbox.scss
├── collapse.scss
├── dialog.scss
├── divider.scss
├── empty.scss
├── form.scss
├── image.scss
├── loading.scss
├── message.scss
├── radio.scss
├── result.scss
├── skeleton.scss
├── steps.scss
├── table.scss
├── tag.scss
├── toast.scss
├── tree.scss
├── mixins/
│   ├── config.scss  # BEM 命名配置
│   └── mixins.scss  # BEM、断点、公共 token 与 Light / Dark 聚合
└── index.scss    # 规范全局样式入口
```

全局主题：

```scss
@use '@luna/theme-chalk';
```

组件或小程序局部挂载主题：

```scss
@use '@luna/theme-chalk/mixins' as ln;

.ln-scope {
  @include ln.theme-light($mini: true);
}
```

`@luna/theme-chalk`、`@luna/theme-chalk/index.scss` 与兼容路径 `@luna/theme-chalk/style` 均指向 `src/index.scss`。无副作用的工具统一从 `@luna/theme-chalk/mixins` 使用；其实现落在视频采用的 `mixins/mixins.scss`。

## BEM

`mixins/config.scss` 统一定义 `ln` 命名空间、`__` 元素分隔符、`--` 修饰符分隔符与 `is-` 状态前缀。组件样式通过 `b`、`e`、`m`、`when` 生成一致的 BEM 选择器：

```scss
@use '@luna/theme-chalk/mixins' as ln;

@include ln.b(button) {
  @include ln.e(icon) {
    display: inline-flex;
  }

  @include ln.m(round) {
    border-radius: ln.v(radius-round);
  }

  @include ln.when(disabled) {
    opacity: 0.5;
  }
}
```

上述代码分别生成 `.ln-button`、`.ln-button__icon`、`.ln-button--round` 与 `.ln-button.is-disabled`。全局 `box-sizing` 只由 `src/index.scss` 输出；Mini 端使用 mixin 入口时不会引入任何全局选择器。
